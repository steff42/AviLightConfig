#!/bin/bash
java -jar bin/AviLightConfig*.jar -Djava.library.path=lib/32

